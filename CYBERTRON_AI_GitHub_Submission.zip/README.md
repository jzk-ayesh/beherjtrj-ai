# CYBERTRON AI — Prototype

Open `index.html` in Chrome or Edge, or publish it using GitHub Pages.

## Included
- Original CYBERTRON logo and Sandra PNG artwork embedded byte-for-byte in the HTML.
- About Us, Research Centre, Cybertron Resources, Guardian Levels.
- Cybertron Academy: Observer, Investigator, Guardian and Cybertronian missions.
- Cyber Points, Digital Footprint Detective and Cyber Rescue Protocol.
- Sandra's local chat knowledge bank with 51 question-and-answer entries, including a dedicated friend-cyberbullying support scenario.
- URL structure review, screenshot OCR and QR image decoding.

## Browser/network notes
- This is a static, local-first prototype. Profile, chat history and progress use browser localStorage.
- URL inspection uses local URL-structure heuristics only. It is not a live reputation scan and cannot certify a website as safe.
- Screenshot OCR loads Tesseract.js on demand from jsDelivr and downloads its English language model; OCR runs in the browser.
- QR decoding uses the browser Barcode Detection API where available, with jsQR loaded from jsDelivr as a fallback.
- OCR/QR helper loading needs an internet connection on first use. If unavailable, screenshot manual text analysis and guided review remain available; QR decoding reports that the decoder could not be loaded.
- No cloud AI model or live threat-intelligence API is connected. Sandra uses a programmed local question-and-answer knowledge base.

## Original artwork
The original logo and Sandra artwork are embedded directly in `index.html`. They are not redrawn, and separate image files are not required.
